package com.edutech.service;

import com.edutech.dto.JobDTO;
import com.edutech.entity.Job;
import com.edutech.entity.JobApplication;
import com.edutech.entity.Proposal;
import com.edutech.entity.User;import com.edutech.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class JobService {

    @Autowired
    private JobRepository jobRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private ProposalRepository proposalRepository;

    @Autowired
    private JobApplicationRepository jobApplicationRepository;

    public Job createJob(Long clientId, Job job) {
        User client = userRepository.findById(clientId)
                .orElseThrow(() -> new RuntimeException("Client not found with id: " + clientId));
        job.setClient(client);
        job.setStatus("OPEN");
        return jobRepository.save(job);
    }

    public List<JobDTO> getAllJobs() {
        return jobRepository.findAll().stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    public Job getJobById(Long id) {
        return jobRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Job not found with id: " + id));
    }

    public Job updateJob(Long id, Job updatedJob) {
        Job existing = getJobById(id);
        existing.setTitle(updatedJob.getTitle());
        existing.setDescription(updatedJob.getDescription());
        existing.setBudget(updatedJob.getBudget());
        existing.setStatus(updatedJob.getStatus());
        return jobRepository.save(existing);
    }

    public void deleteJob(Long id) {
        jobRepository.deleteById(id);
    }

    public Map<String, String> applyToJob(Long jobId, Long userId) {
        Map<String, String> response = new HashMap<>();

        if (hasUserAlreadyApplied(jobId, userId)) {
            response.put("message", "Already Applied.");
            return response;
        }

        Job job = getJobById(jobId);
        User freelancer = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found with id: " + userId));

        // Create proposal with status APPLIED
        Proposal proposal = new Proposal();
        proposal.setBidAmount(0.0);
        proposal.setStatus("APPLIED");
        proposal.setJob(job);
        proposal.setFreelancer(freelancer);
        proposal.setAppliedAt(LocalDateTime.now());
        proposalRepository.save(proposal);

        // Update job status to APPLIED
        job.setStatus("APPLIED");
        jobRepository.save(job);

        // Record in job_application table
        JobApplication application = new JobApplication(jobId, userId, LocalDateTime.now());
        jobApplicationRepository.save(application);

        response.put("message", "Applied successfully.");
        return response;
    }

    public boolean hasUserAlreadyApplied(Long jobId, Long freelancerId) {
        return proposalRepository.existsByJobIdAndFreelancerId(jobId, freelancerId);
    }

public List<JobDTO> getJobsPostedByClient(String username) {
    User client = userRepository.findByUsername(username);

    if (client == null) {
        throw new UsernameNotFoundException("Client not found: " + username);
    }

    return jobRepository.findByClient(client).stream()
            .map(this::toDTO)
            .collect(Collectors.toList());
}

    public Job updateJobStatus(Long jobId, String status) {
        Job job = getJobById(jobId);
        job.setStatus(status);
        return jobRepository.save(job);
    }

    public Map<String, Object> getUserReport() {
        List<User> allUsers = userRepository.findAll();

        List<User> clients = allUsers.stream()
                .filter(u -> u.getRole() == User.Role.CLIENT)
                .collect(Collectors.toList());

        List<User> freelancers = allUsers.stream()
                .filter(u -> u.getRole() == User.Role.FREELANCER)
                .collect(Collectors.toList());

        Map<String, Object> report = new HashMap<>();
        report.put("totalClients", clients.size());
        report.put("totalFreelancers", freelancers.size());
        report.put("clients", clients);
        report.put("freelancers", freelancers);
        return report;
    }

    private JobDTO toDTO(Job job) {
        Long clientId = job.getClient() != null ? job.getClient().getId() : null;
        String clientUsername = job.getClient() != null ? job.getClient().getUsername() : null;
        return new JobDTO(job.getId(), job.getTitle(), job.getDescription(),
                job.getBudget(), job.getStatus(), clientId, clientUsername);
    }
}