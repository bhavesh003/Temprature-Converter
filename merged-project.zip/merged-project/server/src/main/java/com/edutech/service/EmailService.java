package com.edutech.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
public class EmailService {

        @Autowired
        private JavaMailSender mailSender;

        public void sendResetPasswordEmail(
                        String username,
                        String toEmail,
                        String resetLink) {

                SimpleMailMessage message = new SimpleMailMessage();

                message.setTo(toEmail);

                message.setSubject(
                                "Reset Your Password");

                message.setText(
                                "Hello " + username + ",\n\n"
                                                + "We received a request to reset your password "
                                                + "for Freelancer Marketplace.\n\n"
                                                + "Click the link below to reset your password:\n\n"
                                                + resetLink
                                                + "\n\n"
                                                + "This link expires in 15 minutes.\n\n"
                                                + "If you did not request this, please ignore this email.\n\n"
                                                + "Regards,\n"
                                                + "Freelancer Marketplace Team");

                mailSender.send(message);
        }

        public void sendEmailOtp(
                        String toEmail,
                        String otp) {

                SimpleMailMessage message = new SimpleMailMessage();

                message.setTo(toEmail);

                message.setSubject(
                                "Email Verification OTP");

                message.setText(
                                "Your OTP for Freelancer Marketplace is: "
                                                + otp
                                                + "\n\nThis OTP expires in 5 minutes.");

                mailSender.send(message);
        }
}