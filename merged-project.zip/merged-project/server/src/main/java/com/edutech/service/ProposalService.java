package com.edutech.service;

import com.edutech.entity.Job;
import com.edutech.entity.Proposal;
import com.edutech.entity.User;
import com.edutech.repository.JobRepository;
import com.edutech.repository.ProposalRepository;
import com.edutech.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class ProposalService {

    @Autowired
    private ProposalRepository proposalRepository;

    @Autowired
    private JobRepository jobRepository;

    @Autowired
    private UserRepository userRepository;

    public Proposal createProposal(Long freelancerId, Proposal proposal) {
        User freelancer = userRepository.findById(freelancerId)
                .orElseThrow(() -> new RuntimeException("Freelancer not found with id: " + freelancerId));

        proposal.setFreelancer(freelancer);

        if (proposal.getJob() != null && proposal.getJob().getId() != null) {
            Job job = jobRepository.findById(proposal.getJob().getId())
                    .orElseThrow(() -> new RuntimeException("Job not found with id: " + proposal.getJob().getId()));
            proposal.setJob(job);
        }

        if (proposal.getStatus() == null) {
            proposal.setStatus("PENDING");
        }

        if (proposal.getAppliedAt() == null) {
            proposal.setAppliedAt(LocalDateTime.now());
        }

        return proposalRepository.save(proposal);
    }

    public List<Proposal> getAllProposals() {
        return proposalRepository.findAll();
    }

    public Optional<Proposal> getProposalById(Long id) {
        return proposalRepository.findById(id);
    }

    public Proposal updateProposal(Long id, Proposal proposalDetails) {
        Proposal existing = proposalRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Proposal not found with id: " + id));

        existing.setBidAmount(proposalDetails.getBidAmount());
        existing.setStatus(proposalDetails.getStatus());

        return proposalRepository.save(existing);
    }

    public void deleteProposal(Long id) {
        proposalRepository.deleteById(id);
    }

public List<Proposal> getProposalsByFreelancerUsername(String username) {
    User freelancer = userRepository.findByUsername(username);

    if (freelancer == null) {
        throw new UsernameNotFoundException("Freelancer not found: " + username);
    }

    return proposalRepository.findByFreelancerId(freelancer.getId());
}
}