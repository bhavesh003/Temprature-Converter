package com.edutech.entity;

import javax.persistence.*;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "user")
public class User {

   public enum Role {
      ADMIN,
      CLIENT,
      FREELANCER
   }

   @Id
   @GeneratedValue(strategy = GenerationType.IDENTITY)
   private Long id;

   @NotBlank
   @Column(unique = true, nullable = false)
   private String username;

   @NotBlank
   @Column(nullable = false)
   private String password;

   @NotBlank
   @Email
   @Column(unique = true, nullable = false)
   private String email;

   private String emailOtp;
   private LocalDateTime emailOtpExpiry;
   private boolean emailVerified = false;

   private Long contactNumber;

   private String skills;

   private String bio;

   @NotNull
   @Enumerated(EnumType.STRING)
   @Column(nullable = false)
   private Role role = Role.FREELANCER;

   @JsonIgnore
   @OneToMany(mappedBy = "freelancer", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
   private List<Proposal> proposals;

   public User() {
   }

   public User(String username, String password, String email, Long contactNumber, String skills, String bio,
         Role role) {
      this.username = username;
      this.password = password;
      this.email = email;
      this.contactNumber = contactNumber;
      this.skills = skills;
      this.bio = bio;
      this.role = role;
   }

   public String getEmailOtp() {
      return emailOtp;
   }

   public void setEmailOtp(String emailOtp) {
      this.emailOtp = emailOtp;
   }

   public LocalDateTime getEmailOtpExpiry() {
      return emailOtpExpiry;
   }

   public void setEmailOtpExpiry(LocalDateTime emailOtpExpiry) {
      this.emailOtpExpiry = emailOtpExpiry;
   }

   public boolean isEmailVerified() {
      return emailVerified;
   }

   public void setEmailVerified(boolean emailVerified) {
      this.emailVerified = emailVerified;
   }

   public Long getId() {
      return id;
   }

   public void setId(Long id) {
      this.id = id;
   }

   public String getUsername() {
      return username;
   }

   public void setUsername(String username) {
      this.username = username;
   }

   public String getPassword() {
      return password;
   }

   public void setPassword(String password) {
      this.password = password;
   }

   public String getEmail() {
      return email;
   }

   public void setEmail(String email) {
      this.email = email;
   }

   public Long getContactNumber() {
      return contactNumber;
   }

   public void setContactNumber(Long contactNumber) {
      this.contactNumber = contactNumber;
   }

   public String getSkills() {
      return skills;
   }

   public void setSkills(String skills) {
      this.skills = skills;
   }

   public String getBio() {
      return bio;
   }

   public void setBio(String bio) {
      this.bio = bio;
   }

   public Role getRole() {
      return role;
   }

   public void setRole(Role role) {
      this.role = role;
   }

   public List<Proposal> getProposals() {
      return proposals;
   }

   public void setProposals(List<Proposal> proposals) {
      this.proposals = proposals;
   }
}