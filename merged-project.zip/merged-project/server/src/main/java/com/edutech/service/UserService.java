package com.edutech.service;

import com.edutech.entity.User;
import com.edutech.entity.User.Role;
import com.edutech.repository.UserRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;

import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Service
public class UserService implements UserDetailsService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private EmailService emailService;

    // ✅ Temporary OTP storage (for registration)
    private Map<String, String> tempOtpStorage = new HashMap<>();
    private Map<String, LocalDateTime> tempOtpExpiry = new HashMap<>();

    // ✅ Track verified emails
    private Map<String, Boolean> verifiedEmails = new HashMap<>();

    // ✅ REGISTER USER (with OTP check)
    public User registerUser(User user) {

        // ✅ Normalize input
        user.setEmail(user.getEmail().trim().toLowerCase());
        user.setUsername(user.getUsername().trim());

        // ✅ Check duplicate email
        Optional<User> existingEmail = userRepository.findByEmail(user.getEmail());
        if (existingEmail.isPresent()) {
            throw new IllegalArgumentException("Email already exists");
        }

        // ✅ Check duplicate username
        User existingUser = userRepository.findByUsername(user.getUsername());
        if (existingUser != null) {
            throw new IllegalArgumentException("Username already exists");
        }

        if (user.getRole() == null) {
            user.setRole(User.Role.FREELANCER);
        }

        user.setPassword(passwordEncoder.encode(user.getPassword()));
        user.setEmailVerified(true);
        verifiedEmails.remove(user.getEmail());

        return userRepository.save(user);
    }

    // ✅ LOGIN USER
    public Optional<User> loginUser(String username, String password) {

        User user = userRepository.findByUsername(username);

        if (user != null && passwordEncoder.matches(password, user.getPassword())) {
            return Optional.of(user);
        }

        return Optional.empty();
    }

    // ✅ GENERATE EMAIL OTP (for registration)
    public void generateEmailOtp(String email) {

        String otp = String.valueOf((int) (Math.random() * 900000) + 100000);

        emailService.sendEmailOtp(email, otp);

        tempOtpStorage.put(email, otp);
        tempOtpExpiry.put(email, LocalDateTime.now().plusMinutes(5));

        System.out.println("Generated OTP: " + otp);
    }

    // ✅ VERIFY EMAIL OTP
    public boolean verifyEmailOtp(String email, String otp) {

        if (!tempOtpStorage.containsKey(email)) {
            return false;
        }

        String storedOtp = tempOtpStorage.get(email);
        LocalDateTime expiry = tempOtpExpiry.get(email);

        System.out.println("Stored OTP: " + storedOtp);
        System.out.println("Entered OTP: " + otp);

        if (expiry.isBefore(LocalDateTime.now()))
            return false;

        if (!storedOtp.trim().equals(otp.trim()))
            return false;

        // ✅ mark verified
        verifiedEmails.put(email, true);

        // ✅ remove after use
        tempOtpStorage.remove(email);
        tempOtpExpiry.remove(email);

        return true;
    }

    // ✅ RESET PASSWORD
    public void resetPassword(String email, String newPassword) {

        User user = userRepository
                .findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found"));

        user.setPassword(
                passwordEncoder.encode(newPassword));

        userRepository.save(user);
    }

    // ✅ SPRING SECURITY LOGIN SUPPORT
    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        User user = userRepository.findByUsername(username);

        if (user == null) {
            throw new UsernameNotFoundException("User not found");
        }

        User.Role role = user.getRole() != null ? user.getRole() : User.Role.FREELANCER;

        return new org.springframework.security.core.userdetails.User(
                user.getUsername(),
                user.getPassword(),
                Arrays.asList(
                        new SimpleGrantedAuthority(role.name()),
                        new SimpleGrantedAuthority("ROLE_" + role.name())));
    }

    public User getUserByUsername(String username) {
        return userRepository.findByUsername(username);
    }

    public User findByUsername(String username) {
        return userRepository.findByUsername(username);
    }

    public User getUserProfile(long id) {
        return userRepository.findById(id)
                .orElse(null);
    }

    public List<User> getUserRolesDetails() {
        return userRepository.findAll(); // adjust based on your repo
    }

    public List<User> findAllUser() {
        return userRepository.findAll();
    }

}