package com.edutech.controller;

import com.edutech.dto.EmailOtpRequest;
import com.edutech.dto.VerifyEmailOtpRequest;

import com.edutech.entity.User;

import com.edutech.service.UserService;
import com.edutech.util.JwtUtil;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/auth")

@CrossOrigin(origins = "*")
public class AuthController {

        @Autowired
        private UserService userService;

        @Autowired
        private JwtUtil jwtUtil;

        // REGISTER USER
        @PostMapping("/register")

        public ResponseEntity<?> registerUser(@RequestBody User user) {

                try {
                        User savedUser = userService.registerUser(user);
                        return ResponseEntity.status(201).body(savedUser);

                } catch (IllegalArgumentException e) {

                        return ResponseEntity
                                        .badRequest()
                                        .body(Map.of("message", e.getMessage()));
                }
        }

        // LOGIN USER
        @PostMapping("/login")
        public ResponseEntity<?> loginUser(
                        @RequestBody User loginRequest) {

                Optional<User> optionalUser = userService.loginUser(
                                loginRequest.getUsername(),
                                loginRequest.getPassword());

                if (optionalUser.isPresent()) {

                        User user = optionalUser.get();

                        String token = jwtUtil.generateToken(user.getUsername(), user.getRole().name());

                        return ResponseEntity.ok(
                                        Map.of(
                                                        "token", token,
                                                        "role", user.getRole(),
                                                        "username", user.getUsername()));
                }

                return ResponseEntity
                                .status(401)
                                .body(
                                                Map.of(
                                                                "message",
                                                                "Invalid username or password"));
        }

        @GetMapping("/user/{userId}")
        public ResponseEntity<?> getUserProfile(@PathVariable Long userId) {
                try {
                        User user = userService.getUserProfile(userId);
                        return ResponseEntity.ok(user);
                } catch (Exception e) {
                        Map<String, String> error = new HashMap<>();
                        error.put("error", e.getMessage());
                        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(error);
                }
        }

        @GetMapping
        public ResponseEntity<List<User>> getAllUsers() {
                return ResponseEntity.ok(userService.findAllUser());
        }

        // SEND EMAIL OTP
        @PostMapping("/send-email-otp")
        public ResponseEntity<?> sendEmailOtp(@RequestBody EmailOtpRequest request) {

                try {

                        userService.generateEmailOtp(request.getEmail());

                        return ResponseEntity.ok(Map.of("message", "OTP sent successfully"));

                } catch (Exception e) {

                        return ResponseEntity.badRequest().body(
                                        Map.of("message", "Failed to send OTP"));
                }
        }

        // VERIFY EMAIL OTP
        @PostMapping("/verify-email-otp")
        public ResponseEntity<?> verifyEmailOtp(
                        @RequestBody VerifyEmailOtpRequest request) {

                boolean verified = userService.verifyEmailOtp(
                                request.getEmail(),
                                request.getOtp());

                if (!verified) {

                        return ResponseEntity
                                        .badRequest()
                                        .body(
                                                        Map.of(
                                                                        "message",
                                                                        "Invalid or expired OTP"));
                }

                return ResponseEntity.ok(
                                Map.of(
                                                "message",
                                                "OTP verified successfully"));
        }

        // RESET PASSWORD USING EMAIL OTP
        @PostMapping("/reset-password")
        public ResponseEntity<?> resetPassword(
                        @RequestParam String email,
                        @RequestParam String newPassword) {

                userService.resetPassword(
                                email,
                                newPassword);

                return ResponseEntity.ok(
                                Map.of(
                                                "message",
                                                "Password reset successful"));
        }
}