package com.edutech.controller;

import com.edutech.dto.JobDTO;
import com.edutech.entity.Job;
import com.edutech.service.JobService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/jobs")
@CrossOrigin(origins = "*")
public class JobController {

    @Autowired
    private JobService jobService;

    // POST /api/jobs/client/{clientId} — Create job
    @PostMapping("/client/{clientId}")
    public ResponseEntity<Job> createJob(@PathVariable Long clientId,
            @Valid @RequestBody Job job) {
        return ResponseEntity.ok(jobService.createJob(clientId, job));
    }

    // GET /api/jobs — Get all jobs as JobDTO list
    @GetMapping
    public ResponseEntity<List<JobDTO>> getAllJobs() {
        return ResponseEntity.ok(jobService.getAllJobs());
    }

    // GET /api/jobs/{id} — Get job by ID
    @GetMapping("/{id}")
    public ResponseEntity<Job> getJobById(@PathVariable Long id) {
        return ResponseEntity.ok(jobService.getJobById(id));
    }

    // PUT /api/jobs/status/{jobId}?status= — Update job status
    @PutMapping("/status/{jobId}")
    public ResponseEntity<String> updateJobStatus(@PathVariable Long jobId,
            @RequestParam String status) {
        jobService.updateJobStatus(jobId, status);
        return ResponseEntity.ok("Status updated to " + status);
    }

    // POST /api/jobs/{jobId}/apply — Apply to a job
    @PostMapping("/{jobId}/apply")
    public ResponseEntity<Map<String, String>> applyToJob(@PathVariable Long jobId,
            @RequestBody Map<String, Long> body) {
        Long userId = body.get("userId");
        Map<String, String> response = jobService.applyToJob(jobId, userId);
        return ResponseEntity.ok(response);
    }

    // GET /api/jobs/my-jobs — Get jobs posted by logged-in client
    @GetMapping("/my-jobs")
    public ResponseEntity<List<JobDTO>> getMyJobs(Authentication authentication) {
        String username = authentication.getName();
        return ResponseEntity.ok(jobService.getJobsPostedByClient(username));
    }

    // DELETE /api/jobs/{id} — Delete a job
    @DeleteMapping("/{id}")
    public ResponseEntity<Map<String, String>> deleteJob(@PathVariable Long id) {
        jobService.deleteJob(id);
        return ResponseEntity.ok(Map.of("message", "Job deleted successfully"));
    }

    // GET /api/jobs/report/users — Get user report
    @GetMapping("/report/users")
    public ResponseEntity<Map<String, Object>> getUserReport() {
        return ResponseEntity.ok(jobService.getUserReport());
    }

    // PUT /api/jobs/{id} — Update job (full update)
    @PutMapping("/{id}")
    public ResponseEntity<Job> updateJob(@PathVariable Long id,
            @Valid @RequestBody Job updatedJob) {
        return ResponseEntity.ok(jobService.updateJob(id, updatedJob));
    }
}