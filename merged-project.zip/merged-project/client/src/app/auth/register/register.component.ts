import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})
export class RegisterComponent implements OnInit {
  registerForm!: FormGroup;
  loading = false;
  errorMessage = '';
  showPassword = false;
  otpSent = false;
  otpVerified = false;

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private router: Router
  ) { }

  ngOnInit(): void {
    if (this.authService.getLoginStatus()) {
      this.router.navigate(['/dashboard']);
    }
    this.registerForm = this.fb.group({
      username: ['', [Validators.required, Validators.minLength(3)]],
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]],
      contactNumber: [''],
      role: ['FREELANCER', Validators.required],
      emailOtp: ['', Validators.required]
    });
  }

  sendOtp() {
    if (this.otpSent) {
      alert("OTP already sent. Please check your email.");
      return;
    }

    const email = this.registerForm.value.email;

    this.authService
      .sendEmailOtp(email)
      .subscribe({

        next: () => {

          this.otpSent = true;

          alert(
            'OTP sent successfully'
          );
        },

        error: () => {

          alert(
            'Failed to send OTP'
          );
        }
      });
  }

  verifyOtp() {

    const email = this.registerForm.value.email;
    const otp = this.registerForm.value.emailOtp;

    this.authService
      .verifyEmailOtp(email, otp)
      .subscribe({

        next: () => {

          this.otpVerified = true;

          alert('OTP verified successfully');
        },

        error: () => {

          alert('Invalid OTP');
        }
      });
  }


  get f() { return this.registerForm.controls; }

  onSubmit(): void {

    // ✅ PREVENT REGISTER BEFORE OTP VERIFICATION
    if (!this.otpVerified) {

      alert(
        'Please verify email OTP first'
      );

      return;
    }

    this.errorMessage = '';

    if (this.registerForm.invalid) {
      this.registerForm.markAllAsTouched();
      return;
    }

    this.loading = true;

    const payload: any = { ...this.registerForm.value };

    if (payload.contactNumber) {
      payload.contactNumber = Number(payload.contactNumber);
    } else {
      delete payload.contactNumber;
    }

    this.authService.registerUser(payload).subscribe({
      next: () => {
        this.loading = false;
        alert('Registration successful! Please login.');
        this.router.navigate(['/login']);
      },
      error: (err) => {
        this.loading = false;
        const msg = err?.error?.error || err?.error?.message || 'Registration failed. Please try again.';
        this.errorMessage = msg;
      }
    });
  }
}