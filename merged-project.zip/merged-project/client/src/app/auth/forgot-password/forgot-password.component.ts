import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from '../../services/auth.service';
import { Route, Router } from '@angular/router';

@Component({
    selector: 'app-forgot-password',
    templateUrl: './forgot-password.component.html',
    styleUrls: ['./forgot-password.component.scss']
})

export class ForgotPasswordComponent {

    form: FormGroup;
    otpSent = false;
    otpVerified = false;

    constructor(private fb: FormBuilder, private authService: AuthService, private router: Router) {

        this.form =
            this.fb.group({
                email: [
                    '',
                    [
                        Validators.required,
                        Validators.email
                    ]
                ],

                otp: [''],

                newPassword: [
                    '',
                    Validators.required
                ]
            });
    }

    sendOtp() {

        const email =
            this.form.value.email;

        this.authService
            .sendEmailOtp(email)
            .subscribe({

                next: () => {

                    this.otpSent = true;

                    alert(
                        'OTP sent successfully'
                    );
                },

                error: () => {

                    alert(
                        'Failed to send OTP'
                    );
                }
            });
    }

    verifyOtp() {

        const email =
            this.form.value.email;

        const otp =
            this.form.value.otp;

        this.authService
            .verifyEmailOtp(email, otp)
            .subscribe({

                next: () => {

                    this.otpVerified = true;

                    alert(
                        'OTP verified successfully'
                    );
                },

                error: () => {

                    alert(
                        'Invalid OTP'
                    );
                }
            });
    }

    resetPassword() {

        const email =
            this.form.value.email;

        const newPassword =
            this.form.value.newPassword;

        this.authService
            .resetPassword(
                email,
                newPassword
            )
            .subscribe({

                next: () => {

                    alert(
                        'Password reset successful'
                    );
                    this.router.navigate(['/login'])
                },

                error: () => {

                    alert(
                        'Password reset failed'
                    );
                }
            });
    }
}