import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { NgZone } from '@angular/core';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  loginForm!: FormGroup;
  errorMessage = '';
  loading = false;
  showPassword = false;
  captchaText: string = '';
  failedCaptchaAttempts = 0;
  isBlocked = false;
  blockTimer = 60;
  timerInterval: any;

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private router: Router,
    private zone: NgZone
  ) { }

  ngOnInit(): void {

    if (this.authService.getLoginStatus()) {
      this.router.navigate(['/dashboard']);
    }

    this.generateCaptcha();

    this.loginForm = this.fb.group({
      username: ['', Validators.required],
      password: ['', Validators.required],
      captcha: ['', Validators.required]   // ✅ added CAPTCHA control
    });
  }

  // ✅ Generate CAPTCHA
  generateCaptcha() {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    let captcha = '';

    for (let i = 0; i < 5; i++) {
      captcha += chars.charAt(Math.floor(Math.random() * chars.length));
    }

    this.captchaText = captcha;
  }

  get f() {
    return this.loginForm.controls;
  }

  // ✅ Submit with CAPTCHA validation
  onSubmit(): void {

    this.errorMessage = '';

    // ✅ block check
    if (this.isBlocked) {
      this.errorMessage = `Login is blocked. Try again in ${this.blockTimer}s`;
      return;
    }

    // ✅ form validation
    if (this.loginForm.invalid) {
      this.loginForm.markAllAsTouched();
      this.errorMessage = 'Please fill in all required fields correctly.';
      return;
    }

    // ✅ CAPTCHA validation
    if (this.loginForm.value.captcha.toUpperCase() !== this.captchaText) {

      this.failedCaptchaAttempts++;
      this.errorMessage = 'Invalid CAPTCHA. Please try again.';

      this.generateCaptcha();
      this.loginForm.patchValue({ captcha: '' });

      // ✅ Block after 3 attempts
      if (this.failedCaptchaAttempts >= 3) {
        this.blockLogin();
      }

      return;
    }

    // ✅ Reset attempts if correct
    this.failedCaptchaAttempts = 0;

    this.loading = true;

    this.authService.login(this.loginForm.value).subscribe({
      next: (res) => {
        this.authService.saveToken(res.token);
        this.authService.setRole(res.role);
        localStorage.setItem('username', res.username);
        this.router.navigate(['/dashboard']);
      },
      error: () => {
        this.loading = false;
        this.errorMessage = 'Invalid username or password.';
        this.generateCaptcha();
        this.loginForm.patchValue({ captcha: '' });
      }
    });
  }

  blockLogin() {
    this.isBlocked = true;
    this.blockTimer = 60;
    this.errorMessage = `Too many attempts. Login blocked for 60 seconds`;

    this.timerInterval = setInterval(() => {

      // ✅ Important fix → run inside Angular zone
      this.zone.run(() => {

        this.blockTimer--;

        if (this.blockTimer <= 0) {
          this.isBlocked = false;
          this.failedCaptchaAttempts = 0;
          clearInterval(this.timerInterval);
          this.errorMessage = '';
        }

      });

    }, 100);
  }

}