// import { Component, OnInit } from '@angular/core';
// import { Router } from '@angular/router';
// import { AuthService } from '../../services/auth.service';
// import { ProposalService } from '../../services/proposal.service';
// import { Proposal } from '../../model/proposal';

// @Component({
//   selector: 'app-my-proposal',
//   templateUrl: './my-proposal.component.html',
//   styleUrls: ['./my-proposal.component.scss']
// })
// export class MyProposalComponent implements OnInit {
//   proposals: Proposal[] = [];
//   loading = true;
//   roleName = '';

//   constructor(
//     private proposalService: ProposalService,
//     private authService: AuthService,
//     private router: Router
//   ) {}

//   ngOnInit(): void {
//     this.roleName = this.authService.getRole() || '';
//     this.proposalService.getMyProposals().subscribe({
//       next: (data) => { this.proposals = data; this.loading = false; },
//       error: () => { this.loading = false; }
//     });
//   }

//   getStatusClass(status: string): string {
//     const map: any = {
//       'APPLIED': 'status-applied', 'PENDING': 'status-pending',
//       'ACCEPTED': 'status-accepted', 'APPROVED': 'status-accepted',
//       'REJECTED': 'status-rejected'
//     };
//     return map[status] || 'status-pending';
//   }

//   logout(): void {
//     this.authService.logout();
//     this.router.navigate(['/login']);
//   }
// }


import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Proposal } from '../../model/proposal';
import { ProposalService } from '../../services/proposal.service';

@Component({
  selector: 'app-my-proposal',
  templateUrl: './my-proposal.component.html',
  styleUrls: ['./my-proposal.component.scss']
})
export class MyProposalComponent implements OnInit {
  proposals: Proposal[] = [];
  loading = false;
  roleName = '';

  constructor(
    private proposalService: ProposalService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.roleName = localStorage.getItem('role') || '';

    this.proposalService.getMyProposals().subscribe({
      next: (data) => {
        this.proposals = data;
      },
      error: (err) => {
        console.error('Error fetching proposals', err);
      }
    });
  }

  deleteProposal(id: number | undefined): void {
    if (id === undefined || id === null) {
      return;
    }

    const service: any = this.proposalService;

    if (service.deleteProposal) {
      service.deleteProposal(id).subscribe({
        next: () => {
          this.proposals = this.proposals.filter(p => p.id !== id);
        },
        error: () => {
          alert('Failed to delete proposal.');
        }
      });
    }
  }

  getStatusClass(status: string | undefined): string {
    const map: any = {
      APPLIED: 'status-applied',
      PENDING: 'status-pending',
      APPROVED: 'status-accepted',
      ACCEPTED: 'status-accepted',
      REJECTED: 'status-rejected'
    };

    return map[status || 'PENDING'] || 'status-pending';
  }

  logout(): void {
    localStorage.clear();
    this.router.navigate(['/login']);
  }
}