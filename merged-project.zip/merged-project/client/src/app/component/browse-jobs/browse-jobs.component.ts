// import { Component, OnInit } from '@angular/core';
// import { Router } from '@angular/router';
// import { AuthService } from '../../services/auth.service';
// import { JobService } from '../../services/job.service';
// import { Job } from '../../model/job';

// @Component({
//   selector: 'app-browse-jobs',
//   templateUrl: './browse-jobs.component.html',
//   styleUrls: ['./browse-jobs.component.scss']
// })
// export class BrowseJobsComponent implements OnInit {
//   jobs: Job[] = [];
//   allJobs: Job[] = [];
//   roleName = '';
//   username = '';
//   searchTitle = '';
//   filterStatus = 'ALL';
//   loading = true;
//   applyingJobId: number | null = null;

//   // Track which jobs the user has applied to this session
//   appliedJobIds: Set<number> = new Set();

//   statusOptions = ['ALL', 'OPEN', 'APPLIED', 'CLOSED'];

//   constructor(
//     private jobService: JobService,
//     private authService: AuthService,
//     private router: Router
//   ) {}

//   ngOnInit(): void {
//     this.roleName = this.authService.getRole() || '';
//     this.username = localStorage.getItem('username') || 'User';
//     this.loadJobs();
//   }

//   loadJobs(): void {
//     this.loading = true;
//     this.jobService.getJobList().subscribe({
//       next: (jobs) => {
//         this.allJobs = jobs;
//         this.applyFilters();
//         this.loading = false;
//       },
//       error: () => {
//         this.loading = false;
//       }
//     });
//   }

//   applyFilters(): void {
//     let filtered = [...this.allJobs];

//     // Filter by search title
//     if (this.searchTitle.trim()) {
//       filtered = filtered.filter(j =>
//         j.title.toLowerCase().includes(this.searchTitle.toLowerCase().trim())
//       );
//     }

//     // Filter by status
//     if (this.filterStatus !== 'ALL') {
//       filtered = filtered.filter(j => j.status === this.filterStatus);
//     }

//     this.jobs = filtered;
//   }

//   searchJobs(): void {
//     this.applyFilters();
//   }

//   clearSearch(): void {
//     this.searchTitle = '';
//     this.filterStatus = 'ALL';
//     this.applyFilters();
//   }

//   setFilter(status: string): void {
//     this.filterStatus = status;
//     this.applyFilters();
//   }

//   applyJob(job: Job): void {
//     if (!job.id) return;
//     if (this.isAlreadyApplied(job)) return;

//     this.applyingJobId = job.id;
//     const userId = this.authService.getUserId();

//     this.jobService.applyToJob(job.id, userId).subscribe({
//       next: (res) => {
//         this.applyingJobId = null;
//         const msg: string = res?.message || '';

//         if (msg.toLowerCase().includes('already')) {
//           // Mark as applied locally even if backend says already applied
//           this.appliedJobIds.add(job.id!);
//           const jobInList = this.allJobs.find(j => j.id === job.id);
//           if (jobInList) jobInList.status = 'APPLIED';
//           alert('Already Applied.');
//         } else {
//           // Success path
//           this.appliedJobIds.add(job.id!);
//           const jobInList = this.allJobs.find(j => j.id === job.id);
//           if (jobInList) jobInList.status = 'APPLIED';
//           this.applyFilters();
//           alert('Applied successfully.');
//         }
//       },
//       error: (err) => {
//         this.applyingJobId = null;
//         if (err.status === 409) {
//           this.appliedJobIds.add(job.id!);
//           alert('Already Applied.');
//         } else {
//           const msg = err?.error?.message || 'Failed to apply. Please try again.';
//           alert(msg);
//         }
//       }
//     });
//   }

//   isAlreadyApplied(job: Job): boolean {
//     return job.status === 'APPLIED' || this.appliedJobIds.has(job.id!);
//   }

//   isApplying(jobId: number | undefined): boolean {
//     return this.applyingJobId === jobId;
//   }

//   getStatusClass(status: string): string {
//     const map: any = {
//       'OPEN': 'status-open',
//       'APPLIED': 'status-applied',
//       'CLOSED': 'status-closed',
//       'ACCEPTED': 'status-accepted',
//       'REJECTED': 'status-rejected'
//     };
//     return map[status] || 'status-open';
//   }

//   getOpenCount(): number {
//     return this.allJobs.filter(j => j.status === 'OPEN').length;
//   }

//   getAppliedCount(): number {
//     return this.allJobs.filter(j =>
//       j.status === 'APPLIED' || this.appliedJobIds.has(j.id!)
//     ).length;
//   }

//   logout(): void {
//     this.authService.logout();
//     this.router.navigate(['/login']);
//   }
// }


import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Job } from '../../model/job';
import { JobService } from '../../services/job.service';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-browse-jobs',
  templateUrl: './browse-jobs.component.html',
  styleUrls: ['./browse-jobs.component.scss']
})
export class BrowseJobsComponent implements OnInit {
  jobs: Job[] = [];
  job: Job[] = [];
  allJobs: Job[] = [];

  roleName: string | null = '';
  username: string = '';

  searchTitle: string = '';
  filterStatus: string = 'ALL';
  statusOptions: string[] = ['ALL', 'OPEN', 'APPLIED', 'CLOSED'];

  loading = false;

  applyingJobIds: number[] = [];

  constructor(
    private jobService: JobService,
    public authService: AuthService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.roleName = this.authService.getRole();
    this.username =
      localStorage.getItem('username') ||
      localStorage.getItem('name') ||
      'User';

    this.fetchJobs();
  }

  fetchJobs(): void {
    this.loading = true;

    this.jobService.getJobList().subscribe({
      next: (data) => {
        this.allJobs = data || [];
        this.jobs = [...this.allJobs];
        this.job = [...this.allJobs];
        this.loading = false;
      },
      error: (err) => {
        this.loading = false;
        console.error('Error fetching jobs', err);
      }
    });
  }

  loadJobs(): void {
    this.fetchJobs();
  }

  applyFilters(): void {
    let filtered = [...this.allJobs];

    if (this.searchTitle && this.searchTitle.trim() !== '') {
      const search = this.searchTitle.toLowerCase().trim();

      filtered = filtered.filter(j =>
        j.title?.toLowerCase().includes(search)
      );
    }

    if (this.filterStatus && this.filterStatus !== 'ALL') {
      filtered = filtered.filter(j => j.status === this.filterStatus);
    }

    this.jobs = filtered;
    this.job = filtered;
  }

  searchJobs(): void {
    this.applyFilters();
  }

  clearSearch(): void {
    this.searchTitle = '';
    this.filterStatus = 'ALL';
    this.jobs = [...this.allJobs];
    this.job = [...this.allJobs];
  }

  setFilter(status: string): void {
    this.filterStatus = status;
    this.applyFilters();
  }

  getOpenCount(): number {
    return this.allJobs.filter(j => j.status === 'OPEN').length;
  }

  getAppliedCount(): number {
    return this.allJobs.filter(j => j.status === 'APPLIED').length;
  }

  isAlreadyApplied(job: Job | undefined): boolean {
    if (!job) {
      return false;
    }

    return job.status === 'APPLIED';
  }

  isApplying(jobId: number | undefined): boolean {
    if (jobId === undefined || jobId === null) {
      return false;
    }

    return this.applyingJobIds.includes(jobId);
  }

  applyJob(jobOrId: Job | number | undefined): void {
    let jobId: number | undefined;

    if (typeof jobOrId === 'number') {
      jobId = jobOrId;
    } else {
      jobId = jobOrId?.id;
    }

    if (jobId === undefined || jobId === null) {
      return;
    }

    const userId = Number(
      localStorage.getItem('userId') ||
      localStorage.getItem('id') ||
      '1'
    );

    this.applyingJobIds.push(jobId);

    this.jobService.applyToJob(jobId, userId).subscribe({
      next: () => {
        alert('Applied successfully');

        this.jobs = this.jobs.map(j =>
          j.id === jobId ? { ...j, status: 'APPLIED' } : j
        );

        this.job = this.job.map(j =>
          j.id === jobId ? { ...j, status: 'APPLIED' } : j
        );

        this.allJobs = this.allJobs.map(j =>
          j.id === jobId ? { ...j, status: 'APPLIED' } : j
        );

        this.applyingJobIds = this.applyingJobIds.filter(id => id !== jobId);
      },
      error: (err) => {
        this.applyingJobIds = this.applyingJobIds.filter(id => id !== jobId);

        if (err.status === 409) {
          alert('You have already applied to this job.');
        } else {
          alert('Failed to apply. Please try again.');
          console.error('Error details:', err);
        }
      }
    });
  }

  getStatusClass(status: string | undefined): string {
    const map: any = {
      OPEN: 'status-open',
      APPLIED: 'status-applied',
      CLOSED: 'status-closed',
      ACCEPTED: 'status-accepted',
      REJECTED: 'status-rejected',
      PENDING: 'status-pending'
    };

    return map[status || 'OPEN'] || 'status-open';
  }

  logout(): void {
    this.authService.logout();
    this.router.navigate(['/login']);
  }
}