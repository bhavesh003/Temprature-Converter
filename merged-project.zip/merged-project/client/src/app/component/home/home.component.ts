import { Component, OnInit, OnDestroy, HostListener, AfterViewInit, ElementRef } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit, AfterViewInit, OnDestroy {
  isScrolled = false;
  private observer!: IntersectionObserver;

  stats = [
    { value: '12K+', label: 'Freelancers', icon: '👤' },
    { value: '4.8K+', label: 'Projects Shipped', icon: '🚀' },
    { value: '98%', label: 'Satisfaction Rate', icon: '⭐' },
    { value: '$2M+', label: 'Total Paid Out', icon: '💳' }
  ];

  features = [
    {
      tag: 'Matching',
      icon: '⚡',
      cls: 'violet',
      title: 'Instant Talent Matching',
      description: 'AI-powered system connects clients with elite freelancers in real time. No waiting, no guesswork — just the perfect fit.',
      size: 'large'
    },
    {
      tag: 'Security',
      icon: '🔐',
      cls: 'cyan',
      title: 'Escrow Payments',
      description: 'Funds held securely until you approve the work. Every transaction is safe, transparent and guaranteed.',
      size: 'small'
    },
    {
      tag: 'Analytics',
      icon: '📈',
      cls: 'pink',
      title: 'Real-time Dashboard',
      description: 'Track every project, proposal and earning with a powerful live analytics dashboard.',
      size: 'small'
    },
    {
      tag: 'Global',
      icon: '🌐',
      cls: 'blue',
      title: 'World-class Talent Network',
      description: 'Tap into a curated pool of professionals across every domain — design, engineering, marketing and beyond.',
      size: 'wide'
    }
  ];

  steps = [
    { num: '01', title: 'Define Your Vision', desc: 'Post a detailed job with budget, timeline and requirements in under two minutes.' },
    { num: '02', title: 'Review & Select', desc: 'Receive proposals from vetted professionals. Compare, shortlist and pick your match.' },
    { num: '03', title: 'Build & Ship', desc: 'Collaborate with real-time updates, milestone tracking and secure automated payments.' }
  ];

  testimonials = [
    {
      quote: 'NexLancer is the only platform that actually feels built for serious product teams. We hired our entire engineering squad here.',
      author: 'Arjun R.',
      role: 'CTO, BuildStack',
      initials: 'A'
    },
    {
      quote: 'As a freelancer, I\'ve 3× my project income. The proposal system and dashboard remove every friction point that used to waste my time.',
      author: 'Meera S.',
      role: 'Senior Product Designer',
      initials: 'M'
    },
    {
      quote: 'The quality of talent here is in a completely different league. Every hire has been exceptional, fast and within budget.',
      author: 'Kai T.',
      role: 'Founder, DesignFirst Studio',
      initials: 'K'
    }
  ];

  constructor(private router: Router, private authService: AuthService, private el: ElementRef) {}

  ngOnInit(): void {
    if (this.authService.getLoginStatus()) {
      this.router.navigate(['/dashboard']);
    }
  }

  ngAfterViewInit(): void {
    this.observer = new IntersectionObserver(
      (entries) => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            entry.target.classList.add('is-visible');
          }
        });
      },
      { threshold: 0.12, rootMargin: '0px 0px -60px 0px' }
    );

    const targets = this.el.nativeElement.querySelectorAll('.reveal');
    targets.forEach((t: Element) => this.observer.observe(t));
  }

  ngOnDestroy(): void {
    if (this.observer) this.observer.disconnect();
  }

  @HostListener('window:scroll')
  onScroll(): void {
    this.isScrolled = window.scrollY > 60;
  }

  goToLogin(): void { this.router.navigate(['/login']); }
  goToRegister(): void { this.router.navigate(['/register']); }
}
