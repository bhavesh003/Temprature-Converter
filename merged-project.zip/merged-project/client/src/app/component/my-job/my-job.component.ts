// import { Component, OnInit } from '@angular/core';
// import { Router } from '@angular/router';
// import { AuthService } from '../../services/auth.service';
// import { JobService } from '../../services/job.service';
// import { Job } from '../../model/job';

// @Component({
//   selector: 'app-my-job',
//   templateUrl: './my-job.component.html',
//   styleUrls: ['./my-job.component.scss']
// })
// export class MyJobComponent implements OnInit {
//   jobs: Job[] = [];
//   loading = true;
//   roleName = '';

//   constructor(
//     private jobService: JobService,
//     private authService: AuthService,
//     private router: Router
//   ) {}

//   ngOnInit(): void {
//     this.roleName = this.authService.getRole() || '';
//     this.loadMyJobs();
//   }

//   loadMyJobs(): void {
//     this.loading = true;
//     this.jobService.getMyJobs().subscribe({
//       next: (jobs) => {
//         this.jobs = jobs.filter((j: any) => j.status === 'APPLIED' || j.status === 'ACCEPTED' || j.status === 'OPEN' || j.status === 'CLOSED' || j.status === 'REJECTED');
//         this.loading = false;
//       },
//       error: () => { this.loading = false; }
//     });
//   }

//   updateStatus(jobId: number | undefined, status: string): void {
//     if (!jobId) return;
//     this.jobService.updateJobStatus(jobId, status).subscribe({
//       next: () => {
//         const job = this.jobs.find(j => j.id === jobId);
//         if (job) job.status = status;
//       },
//       error: () => alert('Failed to update status.')
//     });
//   }

//   deleteJob(jobId: number | undefined): void {
//     if (!jobId) return;
//     if (!confirm('Delete this job?')) return;
//     this.jobService.deleteJob(jobId).subscribe({
//       next: () => { this.jobs = this.jobs.filter(j => j.id !== jobId); },
//       error: () => alert('Failed to delete job.')
//     });
//   }

//   getStatusClass(status: string): string {
//     const map: any = {
//       'OPEN': 'status-open', 'APPLIED': 'status-applied',
//       'CLOSED': 'status-closed', 'ACCEPTED': 'status-accepted',
//       'REJECTED': 'status-rejected'
//     };
//     return map[status] || 'status-open';
//   }

//   logout(): void {
//     this.authService.logout();
//     this.router.navigate(['/login']);
//   }
// }


import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { JobService } from '../../services/job.service';
import { Job } from '../../model/job';

@Component({
  selector: 'app-my-job',
  templateUrl: './my-job.component.html',
  styleUrls: ['./my-job.component.scss']
})
export class MyJobComponent implements OnInit {
  jobs: Job[] = [];
  loading = false;
  roleName = '';

  constructor(
    private jobService: JobService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.roleName = localStorage.getItem('role') || '';
    this.loadMyJobs();
  }

  loadMyJobs(): void {
    this.loading = true;

    const userId = Number(
      localStorage.getItem('userId') ||
      localStorage.getItem('id') ||
      '1'
    );

    this.jobService.getMyJobs(userId).subscribe({
      next: (data) => {
        this.jobs = data.filter(job => job.status !== 'REJECTED');
        this.loading = false;
      },
      error: (err) => {
        this.loading = false;
        console.error('Error fetching jobs', err);
      }
    });
  }

  updateStatus(jobId: number | undefined, status: string): void {
    if (jobId === undefined || jobId === null) {
      return;
    }

    this.jobService.updateJobStatus(jobId, status).subscribe({
      next: () => {
        this.jobs = this.jobs.map(job =>
          job.id === jobId ? { ...job, status } : job
        );
      },
      error: (err) => {
        console.error('Failed to update status:', err.message);
        console.error('Full error:', err);
      }
    });
  }

  deleteJob(jobId: number | undefined): void {
    if (jobId === undefined || jobId === null) {
      return;
    }

    if (!confirm('Delete this job?')) {
      return;
    }

    const service: any = this.jobService;

    if (service.deleteJob) {
      service.deleteJob(jobId).subscribe({
        next: () => {
          this.jobs = this.jobs.filter(j => j.id !== jobId);
        },
        error: () => {
          alert('Failed to delete job.');
        }
      });
    }
  }

  getStatusClass(status: string | undefined): string {
    const map: any = {
      OPEN: 'status-open',
      APPLIED: 'status-applied',
      CLOSED: 'status-closed',
      ACCEPTED: 'status-accepted',
      REJECTED: 'status-rejected',
      PENDING: 'status-pending'
    };

    return map[status || 'OPEN'] || 'status-open';
  }

  logout(): void {
    localStorage.clear();
    this.router.navigate(['/login']);
  }
}