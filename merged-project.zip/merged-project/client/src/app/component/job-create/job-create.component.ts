import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { JobService } from '../../services/job.service';

@Component({
  selector: 'app-job-create',
  templateUrl: './job-create.component.html',
  styleUrls: ['./job-create.component.scss']
})
export class JobCreateComponent implements OnInit {
  jobForm!: FormGroup;
  clientId!: number;
  loading = false;
  roleName = '';

  constructor(
    private fb: FormBuilder,
    private jobService: JobService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.roleName = localStorage.getItem('role') || '';
    this.clientId = Number(
      localStorage.getItem('userId') ||
      localStorage.getItem('id') ||
      '1'
    );

    this.jobForm = this.fb.group({
      title: ['', Validators.required],
      description: ['', Validators.required],
      budget: ['', [Validators.required, Validators.min(0)]],
      status: ['OPEN', Validators.required]
    });
  }

  get f() {
    return this.jobForm.controls;
  }

  onSubmit(): void {
    if (this.jobForm.invalid) {
      this.jobForm.markAllAsTouched();
      return;
    }

    this.loading = true;

    this.jobService.create(this.clientId, this.jobForm.value).subscribe({
      next: () => {
        this.loading = false;
        alert('Job created successfully!');
        this.router.navigate(['/job-list']);
      },
      error: (err) => {
        this.loading = false;
        console.error('Error creating job:', err);
        alert('Failed to create job.');
      }
    });
  }

  logout(): void {
    localStorage.clear();
    this.router.navigate(['/login']);
  }
}