import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { JobService } from '../../services/job.service';
import { ProposalService } from '../../services/proposal.service';


@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
  roleName: string = '';
  username: string = '';
  stats: any = {};
  recentJobs: any[] = [];
  recentProposals: any[] = [];

  constructor(
    private authService: AuthService,
    private jobService: JobService,
    private proposalService: ProposalService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.roleName = this.authService.getRole() || '';
    this.username = localStorage.getItem('username') || 'User';
    this.loadDashboardData();
  }

  loadDashboardData(): void {
    if (this.roleName === 'ADMIN') {
      this.jobService.getUserReport().subscribe({
        next: (data) => { this.stats = data; },
        error: () => {}
      });
      this.jobService.getJobList().subscribe({
        next: (jobs) => { this.recentJobs = jobs.slice(0, 4); },
        error: () => {}
      });
    } else if (this.roleName === 'CLIENT') {
      this.jobService.getMyJobs().subscribe({
        next: (jobs) => {
          this.recentJobs = jobs.slice(0, 4);
          this.stats.totalJobs = jobs.length;
          this.stats.openJobs = jobs.filter((j: any) => j.status === 'OPEN').length;
          this.stats.appliedJobs = jobs.filter((j: any) => j.status === 'APPLIED').length;
        },
        error: () => {}
      });
    } else if (this.roleName === 'FREELANCER') {
      this.jobService.getJobList().subscribe({
        next: (jobs) => {
          this.recentJobs = jobs.slice(0, 4);
          this.stats.totalJobs = jobs.length;
        },
        error: () => {}
      });
      this.proposalService.getMyProposals().subscribe({
        next: (p) => {
          this.recentProposals = p.slice(0, 3);
          this.stats.totalProposals = p.length;
          this.stats.approvedProposals = p.filter((x: any) => x.status === 'ACCEPTED' || x.status === 'APPROVED').length;
        },
        error: () => {}
      });
    }
  }

  navigate(path: string): void {
    this.router.navigate([path]);
  }

  logout(): void {
    this.authService.logout();
    this.router.navigate(['/login']);
  }

  getStatusClass(status: string): string {
    const map: any = {
      'OPEN': 'status-open', 'APPLIED': 'status-applied',
      'CLOSED': 'status-closed', 'ACCEPTED': 'status-accepted',
      'REJECTED': 'status-rejected', 'PENDING': 'status-pending'
    };
    return map[status] || 'status-open';
  }
}
