// import { Component, OnInit } from '@angular/core';
// import { Router } from '@angular/router';
// import { User } from '../../model/user';
// import { AuthService } from '../../services/auth.service';

// @Component({
//   selector: 'app-profile',
//   templateUrl: './profile.component.html',
//   styleUrls: ['./profile.component.scss']
// })
// export class ProfileComponent implements OnInit {
//   profile: User | null = null;
//   users: User[] = [];
//   roleName = '';
//   errorMessage = '';
//   loading = true;
//   currentRoute = '';

//   constructor(
//     private authService: AuthService,
//     private router: Router
//   ) {}

//   ngOnInit(): void {
//     this.roleName = this.authService.getRole() || '';
//     this.currentRoute = this.router.url;

//     if (this.roleName === 'ADMIN' || this.currentRoute.includes('/users')) {
//       this.loadAllUsers();
//     } else {
//       this.loadProfile();
//     }
//   }

//   loadProfile(): void {
//     const userId = this.authService.getUserId();
//     this.authService.getLoggedInUser(userId).subscribe({
//       next: (user) => { this.profile = user; this.loading = false; },
//       error: () => { this.errorMessage = 'Failed to load profile.'; this.loading = false; }
//     });
//   }

//   loadAllUsers(): void {
//     this.authService.getUsers().subscribe({
//       next: (users) => {
//         this.users = users.filter(u => u.role !== 'ADMIN');
//         this.loading = false;
//       },
//       error: () => { this.loading = false; }
//     });
//     // also load own profile if freelancer viewing /users somehow
//     if (this.roleName !== 'ADMIN') {
//       this.loadProfile();
//     }
//   }

//   getInitials(name: string): string {
//     return name ? name.charAt(0).toUpperCase() : 'U';
//   }

//   getRoleClass(role: string): string {
//     return role?.toLowerCase() || 'freelancer';
//   }

//   logout(): void {
//     this.authService.logout();
//     this.router.navigate(['/login']);
//   }
// }

import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { User, Role } from '../../model/user';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.scss']
})
export class ProfileComponent implements OnInit {
  profile: User | null = null;
  users: User[] = [];
  roleName: string | null = '';
  errorMessage = '';
  loading = false;
  currentRoute = '';

  constructor(
    public authService: AuthService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.roleName = this.authService.getRole();
    this.currentRoute = this.router.url;

    this.fetchProfile();
    this.getUser();
  }

  fetchProfile(): void {
    const userId = Number(
      localStorage.getItem('userId') ||
      localStorage.getItem('id') ||
      '1'
    );

    this.authService.getLoggedInUser(userId).subscribe({
      next: (user) => {
        this.profile = user;
      },
      error: () => {
        this.errorMessage = 'Failed to load profile';
      }
    });
  }

  loadProfile(): void {
    this.fetchProfile();
  }

getUser(): void {
  this.authService.getUsers().subscribe({
    next: (users) => {
      this.users = users.filter(u => u.role !== 'ADMIN');
    },
    error: () => {
      this.errorMessage = 'Failed to load users list.';
    }
  });
}

  loadAllUsers(): void {
    this.getUser();
  }

  getInitials(name: string): string {
    return name ? name.charAt(0).toUpperCase() : 'U';
  }

  getRoleClass(role: string): string {
    return role?.toLowerCase() || 'freelancer';
  }

  logout(): void {
    this.authService.logout();
    this.router.navigate(['/login']);
  }
}