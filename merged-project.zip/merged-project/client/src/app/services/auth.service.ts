import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { LoginRequest } from '../model/loginrequest';
import { LoginResponse } from '../model/login-response';
import { User } from '../model/user';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private baseUrl = `${environment.apiUrl}/api`;

  constructor(private http: HttpClient) { }


  sendEmailOtp(email: string) {
    return this.http.post(`${this.baseUrl}/auth/send-email-otp`, { email: email });
  }
  verifyEmailOtp(email: string, otp: string) {
    return this.http.post(`${this.baseUrl}/auth/verify-email-otp`, { email: email, otp: otp });
  }

  registerUser(user: User): Observable<any> {
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    return this.http.post(`${this.baseUrl}/auth/register`, user, { headers });
  }

  login(loginRequest: LoginRequest): Observable<LoginResponse> {
    return this.http.post<LoginResponse>(`${this.baseUrl}/auth/login`, loginRequest);
  }

  saveToken(token: string): void {
    localStorage.setItem('token', token);
  }

  getToken(): string | null {
    return localStorage.getItem('token');
  }

  setRole(role: string): void {
    localStorage.setItem('role', role);
  }

  getRole(): string | null {
    return localStorage.getItem('role');
  }

  saveUserId(userId: number): void {
    localStorage.setItem('userId', userId.toString());
  }

  getUserId(): number {
    return parseInt(localStorage.getItem('userId') || '0', 10);
  }

  getLoginStatus(): boolean {
    return !!this.getToken();
  }

  logout(): void {
    localStorage.removeItem('token');
    localStorage.removeItem('role');
    localStorage.removeItem('userId');
    localStorage.removeItem('username');
  }

  isAdmin(): boolean { return this.getRole() === 'ADMIN'; }
  isManager(): boolean { return this.getRole() === 'CLIENT'; }
  isCustomer(): boolean { return this.getRole() === 'FREELANCER'; }

  getLoggedInUser(userId: number): Observable<User> {
    const headers = new HttpHeaders({ 'Authorization': `Bearer ${this.getToken()}` });
    return this.http.get<User>(`${this.baseUrl}/auth/user/${userId}`, { headers });
  }

  getUsers(): Observable<User[]> {
    const headers = new HttpHeaders({ 'Authorization': `Bearer ${this.getToken()}` });
    return this.http.get<User[]>(`${this.baseUrl}/auth`, { headers });
  }

  resetPassword(email: string, newPassword: string) {
    return this.http.post(`${this.baseUrl}/auth/reset-password`, null, { params: { email, newPassword } });
  }
}
