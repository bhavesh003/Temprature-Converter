import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { Proposal } from '../model/proposal';

@Injectable({
  providedIn: 'root'
})
export class ProposalService {
  private api = `${environment.apiUrl}/api`;

  constructor(private http: HttpClient) {}

  private getHeaders(): HttpHeaders {
    const token =
      localStorage.getItem('token') ||
      localStorage.getItem('authToken') ||
      'mock-token';

    return new HttpHeaders({
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json'
    });
  }

  create(freelancerId: number, data: any): Observable<any> {
    return this.http.post(`${this.api}/proposals/freelancer/${freelancerId}`, data, {
      headers: this.getHeaders()
    });
  }

  getMyProposals(): Observable<Proposal[]> {
    return this.http.get<Proposal[]>(`${this.api}/proposals/myPropsal`, {
      headers: this.getHeaders()
    });
  }

  deleteProposal(id: number): Observable<any> {
    return this.http.delete(`${this.api}/proposals/${id}`, {
      headers: this.getHeaders()
    });
  }
}