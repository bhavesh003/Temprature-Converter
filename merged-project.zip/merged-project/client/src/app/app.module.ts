import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './auth/login/login.component';
import { RegisterComponent } from './auth/register/register.component';
import { DashboardComponent } from './component/dashboard/dashboard.component';
import { JobListComponent } from './component/job-list/job-list.component';
import { JobCreateComponent } from './component/job-create/job-create.component';
import { MyJobComponent } from './component/my-job/my-job.component';
import { MyProposalComponent } from './component/my-proposal/my-proposal.component';
import { ProfileComponent } from './component/profile/profile.component';
import { ReportComponent } from './component/report/report.component';
import { BrowseJobsComponent } from './component/browse-jobs/browse-jobs.component';
import { HomeComponent } from './component/home/home.component';
import { JwtInterceptor } from './jwt.interceptor';
import { ForgotPasswordComponent } from './auth/forgot-password/forgot-password.component';


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegisterComponent,
    DashboardComponent,
    JobListComponent,
    JobCreateComponent,
    MyJobComponent,
    MyProposalComponent,
    ProfileComponent,
    ReportComponent,
    BrowseJobsComponent,
    HomeComponent,
    ForgotPasswordComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    ReactiveFormsModule,
    FormsModule,
  ],
  providers: [
    { provide: HTTP_INTERCEPTORS, useClass: JwtInterceptor, multi: true }
  ],
  bootstrap: [AppComponent]
})
export class AppModule {}
