// import { Job } from './job';
// import { User } from './user';

// export interface Proposal {
//   id?: number;
//   bidAmount: number;
//   status: string;
//   job?: Job;
//   freelancer?: User;
//   appliedAt?: string;
// }

import { Job } from './job';
import { User } from './user';

export interface Proposal {
  id?: number;
  title?: string;
  jobId?: number;
  bidAmount?: number;
  coverLetter?: string;
  status?: string;
  job?: Job;
  freelancer?: User;
  appliedAt?: string;
}